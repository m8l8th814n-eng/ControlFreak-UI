# freak — controlFREAK

**Wayland gamma control that doesn't care where you log in from.**

`freak` is a gamma-and-color controller for `wlroots`-based Wayland compositors
(sway, river, hyprland, mango, niri-mango, wayfire, …). It controls red,
green, blue gain, contrast and gamma in real time through the
`zwlr_gamma_control_v1` protocol — from a TUI, from a Qt GUI, from a CLI,
from a script, or from another machine over SSH.

## Why this exists

Most Wayland gamma tools — `gammastep`, `wlsunset`, the assorted GNOME/KDE
panels — assume you are sitting at the machine, looking at a usable screen,
inside a graphical session. That assumption breaks the moment you actually
need brightness control:

- **The screen is so dim you can't read it.** A panel cranked to 5%
  backlight with a bad gamma curve is a dead screen. You can't open the
  brightness applet because you can't see the brightness applet.
- **You are on a console / TTY.** No desktop, no GUI tray icon. Just a
  blinking cursor and a compositor running on tty1.
- **You are SSH'd in.** Same problem — no desktop, no GUI, but you still
  need to push the gamma up so whoever's at the keyboard can read the screen.
- **You are on a handheld** (Steam Deck, ROG Ally, Legion Go, GPD Win,
  OneXFly) where you don't always have a keyboard plugged in and you want
  a daemon that Just Stays Up across sessions and reboots.

`freak` covers all of these from one set of binaries:

| You have…                          | Use…                                                           |
| ---------------------------------- | -------------------------------------------------------------- |
| A terminal in the session          | `freak` — TUI with sliders, presets, "gay mode"                |
| A handheld with no keyboard        | `freak-ui` — Qt GUI, 800×400, big touch targets, presets, resolution switching |
| Only SSH / a TTY                   | `freakctl set gamma 95` — talks to the daemon over Unix socket |
| A script that wants to set values  | `freakctl` — line-protocol over `/tmp/controller.sucker`       |

The daemon (`freak --daemon`) holds the gamma controls and keeps them
applied even after your TUI / GUI / SSH session exits, so colour stays
correct across logouts, VT switches, and DPMS sleeps. State is persisted
to disk so a reboot restores your last values.

## Components

| Binary       | Purpose                                                       |
| ------------ | ------------------------------------------------------------- |
| `freak`      | Interactive TUI **and** `--daemon` mode (same binary)         |
| `freakctl`   | Command-line client: get / set / reset / load / save presets  |
| `freak-ui`   | Qt6 GUI for handhelds — 800×400, touch-sized sliders & buttons |

All three ship in a single `freak` package.

Init integration shipped by the `freak` package:

- `freak.service` — systemd **user** unit, starts daemon with your graphical session
- `freak-system.service` — systemd **system** unit, for distros / setups that prefer system services
- `/etc/init.d/freak` — OpenRC init script with `/etc/conf.d/freak` config
- Presets in `/usr/share/freak/presets/` (`warm`, `cool`, `cinema`, `CODE`,
  `acerbudget`, `asus_oled`, `lenovolegions`, …)

## Quick start

### Systemd (most distros)

```sh
systemctl --user enable --now freak
freakctl set gamma 90
freakctl save mypreset
```

If your compositor doesn't import the Wayland environment into systemd,
do it once:

```sh
systemctl --user import-environment WAYLAND_DISPLAY XDG_RUNTIME_DIR
systemctl --user restart freak
```

### OpenRC

Edit `/etc/conf.d/freak` so the daemon knows which user's Wayland session
to attach to:

```sh
FREAK_USER="alice"
FREAK_HOME="/home/alice"
FREAK_WAYLAND_DISPLAY="wayland-1"
FREAK_XDG_RUNTIME_DIR="/run/user/1000"
```

Then:

```sh
rc-update add freak default
rc-service freak start
```

### Without an init system / one-shot

```sh
freak --daemon &
freakctl set red 88
```

### Handheld GUI

`freak-ui` is installed by the `freak` package (needs Python 3, PyQt6, and
`wlr-randr`). Launch it from your launcher or:

```sh
freak-ui
```

The window is locked to 800×400 with 30-pixel slider handles and 36-pixel
buttons, sized for portable screens you control with a thumb.

## The headless use case (the whole point)

Your screen is black. You can barely see the cursor. From another machine:

```sh
ssh you@thatbox
freakctl reset                  # back to neutral
freakctl set gamma 95           # crank it
freakctl load warm              # or load a preset
```

The compositor on the remote side updates its gamma ramps immediately. The
person at the dark screen can suddenly see again. No portal, no D-Bus, no
"please log in graphically first". This works because `freak --daemon` is
already running, attached to that user's Wayland session, listening on
`/tmp/controller.sucker`.

## TUI keys

| Key     | Action                              |
| ------- | ----------------------------------- |
| ← →     | adjust value                        |
| ↑ ↓     | select parameter                    |
| `r`     | reset all to 80% (neutral / 1.0)    |
| `s`     | save preset                         |
| `p`     | open preset panel                   |
| `1`–`9` | load preset by index                |
| `h`     | help                                |
| `c`     | config info                         |
| `q`     | quit                                |

Inside the preset panel: `Enter` loads, `Del` deletes, `Esc` closes.

## Value mapping

Sliders show 0–100%. Internally this maps to −3.0…+2.0 passed to the gamma
ramp formula. Neutral (identity ramp) is at **80%**.

```
internal = (percent / 100) × 5 − 3
```

## Presets

Files in `~/.config/controlorfreak/presets/`. TOML:

```toml
red      = 86.0
green    = 86.0
blue     = 86.0
contrast = 81.0
gamma    = 83.0
```

Bundled: `neutral`, `warm`, `cool`, `cinema`, `freakshow`, `CODE`,
`acerbudget`, `asus_oled`, `lenovolegions`.

## IPC protocol

Line-based text over Unix socket `/tmp/controller.sucker`:

```
GET                          → JSON with current values
SET <field> <0-100>          → OK
RESET                        → OK
LOAD <preset>                → OK / ERROR: ...
SAVE <preset>                → OK / ERROR: ...
PRESETS                      → JSON array of preset names
```

## Requirements

- A wlroots-based Wayland compositor that implements
  `zwlr_gamma_control_manager_v1` (sway, river, hyprland, mango,
  niri-mango, wayfire, …).
- glibc. That's the only runtime dependency for `freak` / `freakctl` —
  they speak the Wayland protocol natively, no `libwayland-client.so` link.
- `freak-ui` additionally needs Python 3, PyQt6, and `wlr-randr` (for the
  in-window resolution switcher).

## Packages

| Distro family   | Path          | Build with                                  |
| --------------- | ------------- | ------------------------------------------- |
| Arch            | `dist/arch/`  | `./makedist.sh && cp freak-*.tar.gz dist/arch/ && cd dist/arch && makepkg -si` |
| Fedora / RHEL   | `dist/rpm/`   | `./dist/rpm/build-rpm.sh`                   |
| Debian / Ubuntu | `dist/deb/`   | `./dist/deb/build-deb.sh`                   |

## License

MIT.
