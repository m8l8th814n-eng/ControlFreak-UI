use crate::{
    config::{load as load_config, AppConfig, ColorMode},
    gamma::GammaClient,
    ipc::{send_and_recv, SOCKET_PATH},
    params::Params,
    preset::{list_presets, load_preset, load_state, save_preset, save_state},
    sway::set_floating,
};
use crossterm::{
    event::{self, Event, KeyCode, KeyEventKind},
    execute,
    terminal::{disable_raw_mode, enable_raw_mode, EnterAlternateScreen, LeaveAlternateScreen},
};
use ratatui::{
    backend::CrosstermBackend,
    layout::{Constraint, Direction, Layout, Rect},
    style::{Color, Modifier, Style},
    text::{Line, Span},
    widgets::{Block, Borders, Paragraph},
    Frame, Terminal,
};
use crate::ipc::{params_to_json, parse_cmd, Cmd};
use std::io;
use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::UnixListener;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

const INFO_CONTENT: &str = include_str!("../info.txt");

const HELP_TEXT: &[&str] = &[
    "← → adjust value",
    "↑ ↓ select param",
    "(r)eset all to 80%",
    "(s)ave preset",
    "(p)resets panel",
    "(h)elp toggle",
    "(c)onfig info",
    "(q)uit",
    "1-9 load preset",
    "Enter load selected",
    "",
    "PRESETS panel:",
    "↑ ↓ navigate",
    "Enter load",
    "Del delete preset",
    "Esc close",
    "",
    "SAVE panel:",
    "type name + Enter",
    "Esc cancel",
];

#[derive(Clone, Copy, PartialEq)]
enum Field {
    Red,
    Green,
    Blue,
    Contrast,
    Gamma,
}

const FIELDS: [Field; 5] = [
    Field::Red,
    Field::Green,
    Field::Blue,
    Field::Contrast,
    Field::Gamma,
];

#[derive(PartialEq)]
enum Mode {
    Normal,
    Presets,
    Save,
    Config,
    Help,
}

struct AppState {
    params: Params,
    selected: usize,
    mode: Mode,
    presets: Vec<String>,
    preset_sel: usize,
    preset_scroll: usize,
    save_input: String,
    status: String,
    daemon_connected: bool,
    cfg: AppConfig,
    start: Instant,
    standalone_gamma: Option<GammaClient>,
    show_help: bool,
    ipc_rx: std::sync::mpsc::Receiver<Params>,
    shared_params: Arc<Mutex<Params>>,
}

impl AppState {
    fn new() -> Self {
        let cfg = load_config();
        let daemon_connected = std::os::unix::net::UnixStream::connect(SOCKET_PATH).is_ok();
        let params = if daemon_connected {
            fetch_params_from_daemon().unwrap_or_else(load_state)
        } else {
            load_state()
        };
        let presets = list_presets();
        let mut standalone_gamma = None;
        if !daemon_connected {
            if let Some(mut gc) = GammaClient::connect() {
                gc.acquire_controls();
                gc.apply(&params);
                standalone_gamma = Some(gc);
            }
        }
        let shared_params = Arc::new(Mutex::new(params.clone()));
        let (ipc_tx, ipc_rx) = std::sync::mpsc::channel::<Params>();
        if !daemon_connected {
            start_tui_ipc(Arc::clone(&shared_params), ipc_tx);
        }
        Self {
            params,
            selected: 0,
            mode: Mode::Normal,
            presets,
            preset_sel: 0,
            preset_scroll: 0,
            save_input: String::new(),
            status: if daemon_connected {
                "daemon connected".to_string()
            } else {
                "ipc ready  /tmp/controller.sucker".to_string()
            },
            daemon_connected,
            cfg,
            start: Instant::now(),
            standalone_gamma,
            show_help: false,
            ipc_rx,
            shared_params,
        }
    }

    fn field_val(&self, f: Field) -> f64 {
        match f {
            Field::Red => self.params.red,
            Field::Green => self.params.green,
            Field::Blue => self.params.blue,
            Field::Contrast => self.params.contrast,
            Field::Gamma => self.params.gamma,
        }
    }

    fn set_field(&mut self, f: Field, v: f64) {
        let clamped = v.clamp(0.0, 100.0);
        match f {
            Field::Red => self.params.red = clamped,
            Field::Green => self.params.green = clamped,
            Field::Blue => self.params.blue = clamped,
            Field::Contrast => self.params.contrast = clamped,
            Field::Gamma => self.params.gamma = clamped,
        }
    }

    fn current_field(&self) -> Field {
        FIELDS[self.selected]
    }

    fn adjust(&mut self, delta: f64) {
        let f = self.current_field();
        let v = self.field_val(f) + delta;
        self.set_field(f, v);
        self.push_change();
    }

    fn push_change(&mut self) {
        if self.daemon_connected {
            let f = self.current_field();
            let name = field_name(f);
            let v = self.field_val(f);
            let _ = send_and_recv(&format!("SET {} {:.1}", name, v));
        } else {
            if let Some(ref mut gc) = self.standalone_gamma {
                gc.apply(&self.params);
            }
            save_state(&self.params);
            if let Ok(mut sp) = self.shared_params.lock() {
                *sp = self.params.clone();
            }
        }
    }

    fn do_reset(&mut self) {
        self.params = Params::reset();
        if self.daemon_connected {
            let _ = send_and_recv("RESET");
        } else {
            if let Some(ref mut gc) = self.standalone_gamma {
                gc.apply(&self.params);
            }
            save_state(&self.params);
        }
        self.status = "reset to neutral (80%)".to_string();
    }

    fn load_preset_by_name(&mut self, name: &str) {
        if self.daemon_connected {
            match send_and_recv(&format!("LOAD {}", name)) {
                Ok(r) if r == "OK" => {
                    if let Some(p) = load_preset(name) {
                        self.params = p;
                    }
                    self.status = format!("loaded: {}", name);
                }
                Ok(e) => self.status = e,
                Err(e) => self.status = format!("err: {}", e),
            }
        } else {
            if let Some(p) = load_preset(name) {
                self.params = p.clone();
                if let Some(ref mut gc) = self.standalone_gamma {
                    gc.apply(&p);
                }
                save_state(&p);
                self.status = format!("loaded: {}", name);
            } else {
                self.status = format!("not found: {}", name);
            }
        }
    }

    fn load_preset_by_idx(&mut self, idx: usize) {
        let presets = self.presets.clone();
        if let Some(name) = presets.get(idx) {
            let n = name.clone();
            self.load_preset_by_name(&n);
        }
    }

    fn do_save(&mut self, name: &str) {
        let name = name.trim().to_string();
        if name.is_empty() {
            self.status = "save cancelled: empty name".to_string();
            return;
        }
        if self.daemon_connected {
            match send_and_recv(&format!("SAVE {}", name)) {
                Ok(r) if r == "OK" => self.status = format!("saved: {}", name),
                Ok(e) => self.status = e,
                Err(e) => self.status = format!("err: {}", e),
            }
        } else {
            match save_preset(&name, &self.params) {
                Ok(_) => self.status = format!("saved: {}", name),
                Err(e) => self.status = format!("save failed: {}", e),
            }
        }
        self.presets = list_presets();
        self.presets.sort();
    }

    fn delete_preset(&mut self, name: &str) {
        let mut path = crate::preset::preset_dir();
        path.push(format!("{}.freak", name));
        let _ = std::fs::remove_file(&path);
        self.presets = list_presets();
        self.presets.sort();
        if self.preset_sel >= self.presets.len() && self.preset_sel > 0 {
            self.preset_sel -= 1;
        }
        self.status = format!("deleted: {}", name);
    }

    fn scroll_presets_to_selected(&mut self, visible: usize) {
        if self.preset_sel < self.preset_scroll {
            self.preset_scroll = self.preset_sel;
        } else if self.preset_sel >= self.preset_scroll + visible {
            self.preset_scroll = self.preset_sel + 1 - visible;
        }
    }
}

fn fetch_params_from_daemon() -> Option<Params> {
    let resp = send_and_recv("GET").ok()?;
    parse_json_params(&resp)
}

fn start_tui_ipc(shared: Arc<Mutex<Params>>, tx: std::sync::mpsc::Sender<Params>) {
    let _ = std::fs::remove_file(SOCKET_PATH);
    let listener = match UnixListener::bind(SOCKET_PATH) {
        Ok(l) => l,
        Err(_) => return,
    };
    std::thread::spawn(move || {
        for stream in listener.incoming().flatten() {
            let shared2 = Arc::clone(&shared);
            let tx2 = tx.clone();
            std::thread::spawn(move || {
                let mut writer = stream.try_clone().ok();
                let reader = BufReader::new(stream);
                for line in reader.lines().flatten() {
                    let response = {
                        let mut p = shared2.lock().unwrap();
                        match parse_cmd(&line) {
                            Some(Cmd::Get) => params_to_json(&p),
                            Some(Cmd::Reset) => {
                                *p = Params::reset();
                                let np = p.clone();
                                drop(p);
                                save_state(&np);
                                let _ = tx2.send(np);
                                "OK".to_string()
                            }
                            Some(Cmd::Set { field, value }) => {
                                match field.as_str() {
                                    "red"      => p.red      = value.clamp(0.0, 100.0),
                                    "green"    => p.green    = value.clamp(0.0, 100.0),
                                    "blue"     => p.blue     = value.clamp(0.0, 100.0),
                                    "contrast" => p.contrast = value.clamp(0.0, 100.0),
                                    "gamma"    => p.gamma    = value.clamp(0.0, 100.0),
                                    _ => {}
                                }
                                let np = p.clone();
                                drop(p);
                                save_state(&np);
                                let _ = tx2.send(np);
                                "OK".to_string()
                            }
                            Some(Cmd::Load(name)) => match load_preset(&name) {
                                Some(preset) => {
                                    *p = preset.clone();
                                    drop(p);
                                    save_state(&preset);
                                    let _ = tx2.send(preset);
                                    "OK".to_string()
                                }
                                None => format!("ERROR: preset '{}' not found", name),
                            },
                            Some(Cmd::Save(name)) => {
                                match save_preset(&name, &p) {
                                    Ok(_) => "OK".to_string(),
                                    Err(e) => format!("ERROR: {}", e),
                                }
                            }
                            Some(Cmd::ListPresets) => {
                                let list = crate::preset::list_presets();
                                format!("[{}]", list.iter().map(|s| format!("\"{}\"", s)).collect::<Vec<_>>().join(","))
                            }
                            None => "ERROR: unknown command".to_string(),
                        }
                    };
                    if let Some(ref mut w) = writer {
                        let _ = writeln!(w, "{}", response);
                    }
                }
            });
        }
    });
}

fn parse_json_params(s: &str) -> Option<Params> {
    let get = |key: &str| -> Option<f64> {
        let pat = format!("\"{}\":", key);
        let pos = s.find(&pat)? + pat.len();
        let rest = s[pos..].trim_start();
        let end = rest
            .find(|c: char| c == ',' || c == '}')
            .unwrap_or(rest.len());
        rest[..end].trim().parse().ok()
    };
    Some(Params {
        red: get("red")?,
        green: get("green")?,
        blue: get("blue")?,
        contrast: get("contrast")?,
        gamma: get("gamma")?,
    })
}

fn field_name(f: Field) -> &'static str {
    match f {
        Field::Red => "red",
        Field::Green => "green",
        Field::Blue => "blue",
        Field::Contrast => "contrast",
        Field::Gamma => "gamma",
    }
}

fn field_label(f: Field) -> &'static str {
    match f {
        Field::Red => "RED  ",
        Field::Green => "GREEN",
        Field::Blue => "BLUE ",
        Field::Contrast => "CNTR ",
        Field::Gamma => "GAMMA",
    }
}

fn field_base_color(f: Field) -> Color {
    match f {
        Field::Red => Color::Red,
        Field::Green => Color::Green,
        Field::Blue => Color::Blue,
        Field::Contrast => Color::Yellow,
        Field::Gamma => Color::Magenta,
    }
}

fn field_selected_color(f: Field) -> Color {
    match f {
        Field::Red      => Color::Rgb(255, 150,  50),
        Field::Green    => Color::Rgb(100, 240, 120),
        Field::Blue     => Color::Rgb( 80, 140, 255),
        Field::Contrast => Color::Rgb(255,  80, 200),
        Field::Gamma    => Color::Rgb(255,  80, 200),
    }
}

const LGRAY: Color = Color::Rgb(160, 160, 160);
const LBLUE: Color = Color::Rgb(140, 200, 255);

fn hsv_to_rgb(h: f64) -> (u8, u8, u8) {
    let h = h % 360.0;
    let c = 1.0_f64;
    let x = c * (1.0 - ((h / 60.0) % 2.0 - 1.0).abs());
    let (r, g, b) = if h < 60.0 {
        (c, x, 0.0)
    } else if h < 120.0 {
        (x, c, 0.0)
    } else if h < 180.0 {
        (0.0, c, x)
    } else if h < 240.0 {
        (0.0, x, c)
    } else if h < 300.0 {
        (x, 0.0, c)
    } else {
        (c, 0.0, x)
    };
    ((r * 255.0) as u8, (g * 255.0) as u8, (b * 255.0) as u8)
}

fn gay(t: f64, phase: f64) -> Color {
    let (r, g, b) = hsv_to_rgb((t * 60.0 + phase) % 360.0);
    Color::Rgb(r, g, b)
}

fn g(is_gay: bool, t: f64, phase: f64, fallback: Color) -> Color {
    if is_gay {
        gay(t, phase)
    } else {
        fallback
    }
}

fn render(f: &mut Frame, app: &AppState) {
    let t = app.start.elapsed().as_secs_f64();
    let gm = app.cfg.color_mode == ColorMode::Gay;

    let full = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(1),
            Constraint::Length(10),
            Constraint::Min(6),
        ])
        .split(f.area());

    render_title(f, full[0], app, gm, t);
    render_sliders(f, full[1], app, gm, t);
    render_bottom(f, full[2], app, gm, t);
}

fn title_sub_color(t: f64, phase: f64) -> Color {
    let p = t * 999.0 + phase;
    let pink = (255.0_f64, 80.0_f64, 200.0_f64);
    let purple = (160.0_f64, 30.0_f64, 240.0_f64);
    let blue = (70.0_f64, 100.0_f64, 255.0_f64);
    let w0 = ((p).sin() * 0.5 + 0.5).powi(2);
    let w1 = ((p + 2.094).sin() * 0.5 + 0.5).powi(2);
    let w2 = ((p + 4.189).sin() * 0.5 + 0.5).powi(2);
    let sum = (w0 + w1 + w2).max(0.001);
    let r = (pink.0 * w0 + purple.0 * w1 + blue.0 * w2) / sum;
    let g = (pink.1 * w0 + purple.1 * w1 + blue.1 * w2) / sum;
    let b = (pink.2 * w0 + purple.2 * w1 + blue.2 * w2) / sum;
    Color::Rgb(r as u8, g as u8, b as u8)
}

fn render_title(f: &mut Frame, area: Rect, _app: &AppState, _gm: bool, t: f64) {
    let pink       = Color::Rgb(255,  80, 200);
    let purple     = Color::Rgb(160,  30, 240);
    let blue       = Color::Rgb( 70, 100, 255);
    let light_blue = Color::Rgb(140, 200, 255);
    let bold       = Modifier::BOLD;

    let blink_on = (t * 5.0).floor() as usize % 9 == 0;
    let c_color = if blink_on { Color::Rgb(220, 220, 255) } else { pink };

    let spans = vec![
        Span::styled("  ", Style::default()),
        Span::styled("C", Style::default().fg(c_color).add_modifier(bold)),
        Span::styled("O", Style::default().fg(purple).add_modifier(bold)),
        Span::styled("NTROL", Style::default().fg(light_blue).add_modifier(bold)),
        Span::styled(" ", Style::default()),
        Span::styled("F", Style::default().fg(blue).add_modifier(bold)),
        Span::styled("REAK", Style::default().fg(light_blue).add_modifier(bold)),
    ];

    f.render_widget(Paragraph::new(Line::from(spans)), area);
}

fn render_sliders(f: &mut Frame, area: Rect, app: &AppState, gm: bool, t: f64) {
    let block = Block::default()
        .borders(Borders::ALL)
        .border_style(Style::default().fg(g(gm, t, 30.0, Color::DarkGray)));
    let inner = block.inner(area);
    f.render_widget(block, area);

    let rows = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(1),
            Constraint::Length(1),
            Constraint::Length(1),
            Constraint::Length(1),
            Constraint::Length(1),
            Constraint::Length(1),
        ])
        .margin(1)
        .split(inner);

    for (i, &field) in FIELDS.iter().enumerate() {
        let val = app.field_val(field);
        let selected = app.selected == i && app.mode == Mode::Normal;
        render_slider(f, rows[i], field, val, selected, gm, t, i);
    }

    let hint_style = Style::default().fg(g(gm, t, 270.0, Color::DarkGray));
    let key_style = Style::default().fg(g(gm, t, 60.0, Color::Yellow));
    let hints = Line::from(vec![
        Span::styled("  ←→", key_style),
        Span::styled(" adj  ", hint_style),
        Span::styled("↑↓", key_style),
        Span::styled(" sel  ", hint_style),
        Span::styled("r", key_style),
        Span::styled("eset  ", hint_style),
        Span::styled("s", key_style),
        Span::styled("ave  ", hint_style),
        Span::styled("p", key_style),
        Span::styled("resets  ", hint_style),
        Span::styled("h", key_style),
        Span::styled("elp  ", hint_style),
        Span::styled("q", key_style),
        Span::styled("uit  ", hint_style),
        Span::styled("1-9", key_style),
        Span::styled(" load preset", hint_style),
    ]);
    f.render_widget(Paragraph::new(hints), rows[5]);
}

fn render_slider(
    f: &mut Frame,
    area: Rect,
    field: Field,
    val: f64,
    selected: bool,
    gm: bool,
    t: f64,
    idx: usize,
) {
    if area.width < 12 {
        return;
    }
    let label = field_label(field);
    let pct = val.round() as u16;
    let bar_width = (area.width as i32 - 13).max(1) as u16;
    let filled = ((val / 100.0) * bar_width as f64).round() as u16;

    let phase = idx as f64 * 72.0;
    let bar_color = if gm { gay(t, phase) } else { Color::Rgb(60, 90, 160) };
    let label_style = if selected {
        Style::default()
            .fg(if gm { gay(t, phase) } else { field_selected_color(field) })
            .add_modifier(Modifier::BOLD)
    } else {
        Style::default().fg(g(gm, t, phase + 180.0, Color::DarkGray))
    };
    let pct_style = Style::default().fg(g(gm, t, phase + 90.0, LGRAY));

    let mut spans = vec![
        Span::styled(format!("{} ", label), label_style),
        Span::styled("[", Style::default().fg(Color::DarkGray)),
    ];
    for i in 0..bar_width {
        let c = if i < filled { '█' } else { '░' };
        spans.push(Span::styled(
            c.to_string(),
            Style::default().fg(if i < filled {
                bar_color
            } else {
                Color::DarkGray
            }),
        ));
    }
    spans.push(Span::styled("]", Style::default().fg(Color::DarkGray)));
    spans.push(Span::styled(format!(" {:3}%", pct), pct_style));
    f.render_widget(Paragraph::new(Line::from(spans)), area);
}

fn render_bottom(f: &mut Frame, area: Rect, app: &AppState, gm: bool, t: f64) {
    let thirds = Layout::default()
        .direction(Direction::Horizontal)
        .constraints([
            Constraint::Percentage(30),
            Constraint::Percentage(40),
            Constraint::Percentage(30),
        ])
        .split(area);

    render_info_panel(f, thirds[0], app, gm, t);
    render_presets_panel(f, thirds[1], app, gm, t);
    render_right_panel(f, thirds[2], app, gm, t);
}

fn render_info_panel(f: &mut Frame, area: Rect, _app: &AppState, gm: bool, t: f64) {
    let block = Block::default()
        .title(Span::styled(
            " INFO ",
            Style::default().fg(g(gm, t, 45.0, Color::DarkGray)),
        ))
        .borders(Borders::ALL)
        .border_style(Style::default().fg(g(gm, t, 45.0, Color::DarkGray)));
    let inner = block.inner(area);
    f.render_widget(block, area);

    let lines: Vec<Line> = INFO_CONTENT
        .lines()
        .enumerate()
        .map(|(i, l)| {
            let c = if gm { gay(t, i as f64 * 35.0) } else { Color::White };
            Line::from(Span::styled(format!(" {}", l), Style::default().fg(c)))
        })
        .collect();
    f.render_widget(Paragraph::new(lines), inner);
}

fn render_presets_panel(f: &mut Frame, area: Rect, app: &AppState, gm: bool, t: f64) {
    let is_active = app.mode == Mode::Presets || app.mode == Mode::Save;
    let border_color = if is_active {
        g(gm, t, 120.0, Color::Yellow)
    } else {
        g(gm, t, 120.0, Color::DarkGray)
    };
    let block = Block::default()
        .title(Span::styled(" PRESETS ", Style::default().fg(border_color)))
        .borders(Borders::ALL)
        .border_style(Style::default().fg(border_color));
    let inner = block.inner(area);
    f.render_widget(block, area);

    if app.mode == Mode::Save {
        render_save_input(f, inner, app, gm, t);
        return;
    }

    let visible = inner.height as usize;
    let scroll = app.preset_scroll;

    if app.presets.is_empty() {
        f.render_widget(
            Paragraph::new(Line::from(Span::styled(
                " no presets — press (s)ave",
                Style::default().fg(Color::DarkGray),
            ))),
            inner,
        );
        return;
    }

    let lines: Vec<Line> = app
        .presets
        .iter()
        .enumerate()
        .skip(scroll)
        .take(visible)
        .map(|(i, name)| {
            let selected = i == app.preset_sel && app.mode == Mode::Presets;
            let c = if gm { gay(t, i as f64 * 30.0) } else { LBLUE };
            let dim = if gm { gay(t, i as f64 * 30.0 + 180.0) } else { Color::DarkGray };
            let style = if selected {
                Style::default().fg(c).add_modifier(Modifier::BOLD)
            } else {
                Style::default().fg(c)
            };
            let idx_str = if i < 9 {
                format!("[{}]", i + 1)
            } else {
                "   ".to_string()
            };
            let line = Line::from(vec![
                Span::styled(format!(" {} ", idx_str), Style::default().fg(dim)),
                Span::styled(name.clone(), style),
            ]);
            line
        })
        .collect();

    f.render_widget(Paragraph::new(lines), inner);

    if app.mode == Mode::Presets {
        let hint = Paragraph::new(Line::from(vec![
            Span::styled(" Enter", Style::default().fg(g(gm, t, 0.0, Color::Yellow))),
            Span::styled(" load  ", Style::default().fg(Color::DarkGray)),
            Span::styled("Del", Style::default().fg(g(gm, t, 120.0, Color::Red))),
            Span::styled(" delete  ", Style::default().fg(Color::DarkGray)),
            Span::styled("Esc", Style::default().fg(Color::DarkGray)),
            Span::styled(" close", Style::default().fg(Color::DarkGray)),
        ]));
        if inner.height > 1 {
            let hint_area = Rect {
                y: inner.y + inner.height - 1,
                height: 1,
                ..inner
            };
            f.render_widget(hint, hint_area);
        }
    }
}

fn render_save_input(f: &mut Frame, area: Rect, app: &AppState, gm: bool, t: f64) {
    let prompt = Line::from(vec![
        Span::styled(
            " save as: ",
            Style::default().fg(g(gm, t, 60.0, Color::Yellow)),
        ),
        Span::styled(
            format!("{}_", app.save_input),
            Style::default()
                .fg(g(gm, t, 0.0, LGRAY))
                .add_modifier(Modifier::BOLD),
        ),
    ]);
    let lines = vec![
        Line::from(""),
        prompt,
        Line::from(""),
        Line::from(Span::styled(
            " Enter to save  Esc cancel",
            Style::default().fg(Color::DarkGray),
        )),
    ];
    f.render_widget(Paragraph::new(lines), area);
}

fn render_right_panel(f: &mut Frame, area: Rect, app: &AppState, gm: bool, t: f64) {
    let show_help = app.mode == Mode::Help || app.show_help;
    let title = if show_help { " HELP " } else { " CONFIG " };
    let border_color = g(gm, t, 200.0, Color::DarkGray);
    let block = Block::default()
        .title(Span::styled(title, Style::default().fg(border_color)))
        .borders(Borders::ALL)
        .border_style(Style::default().fg(border_color));
    let inner = block.inner(area);
    f.render_widget(block, area);

    if show_help {
        let visible = inner.height as usize;
        let lines: Vec<Line> = HELP_TEXT
            .iter()
            .take(visible)
            .enumerate()
            .map(|(i, l)| {
                let c = if gm {
                    gay(t, i as f64 * 18.0)
                } else if l.is_empty() {
                    Color::DarkGray
                } else {
                    Color::Gray
                };
                Line::from(Span::styled(format!(" {}", l), Style::default().fg(c)))
            })
            .collect();
        f.render_widget(Paragraph::new(lines), inner);
    } else {
        render_config_info(f, inner, app, gm, t);
    }
}

fn render_config_info(f: &mut Frame, area: Rect, app: &AppState, gm: bool, t: f64) {
    let mode_str = match app.cfg.color_mode {
        ColorMode::Gay => "gay (rainbow)",
        ColorMode::Default => "default",
    };
    let dim = Color::DarkGray;
    let val = g(gm, t, 0.0, LGRAY);
    let lines = vec![
        Line::from(vec![
            Span::styled(" colors: ", Style::default().fg(dim)),
            Span::styled(mode_str, Style::default().fg(val)),
        ]),
        Line::from(vec![
            Span::styled(" socket: ", Style::default().fg(dim)),
            Span::styled("/tmp/controller.sucker", Style::default().fg(val)),
        ]),
        Line::from(vec![
            Span::styled(" state:  ", Style::default().fg(dim)),
            Span::styled(
                "~/.config/controlorfreak/state.freak",
                Style::default().fg(val),
            ),
        ]),
        Line::from(vec![
            Span::styled(" presets:", Style::default().fg(dim)),
            Span::styled(
                "~/.config/controlorfreak/presets/",
                Style::default().fg(val),
            ),
        ]),
        Line::from(""),
        Line::from(Span::styled(
            " press (h) for help",
            Style::default().fg(dim),
        )),
    ];
    f.render_widget(Paragraph::new(lines), area);
}

pub fn run() {
    enable_raw_mode().expect("raw mode");
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen).expect("alt screen");
    let backend = CrosstermBackend::new(stdout);
    let mut terminal = Terminal::new(backend).expect("terminal");

    set_floating();

    let mut app = AppState::new();
    app.presets.sort();

    loop {
        while let Ok(new_params) = app.ipc_rx.try_recv() {
            app.params = new_params;
            if let Some(ref mut gc) = app.standalone_gamma {
                gc.apply(&app.params);
            }
            app.status = "updated via ipc".to_string();
        }

        terminal.draw(|f| render(f, &app)).expect("draw");

        if !event::poll(Duration::from_millis(33)).unwrap_or(false) {
            continue;
        }

        let Ok(Event::Key(key)) = event::read() else {
            continue;
        };
        if key.kind != KeyEventKind::Press {
            continue;
        }

        match app.mode {
            Mode::Normal => match key.code {
                KeyCode::Char('q') => break,
                KeyCode::Char('r') => app.do_reset(),
                KeyCode::Char('h') => {
                    app.show_help = !app.show_help;
                    if app.show_help {
                        app.mode = Mode::Help;
                    } else {
                        app.mode = Mode::Normal;
                    }
                }
                KeyCode::Char('p') => {
                    app.presets = list_presets();
                    app.presets.sort();
                    app.preset_sel = 0;
                    app.preset_scroll = 0;
                    app.mode = Mode::Presets;
                }
                KeyCode::Char('s') => {
                    app.save_input.clear();
                    app.mode = Mode::Save;
                }
                KeyCode::Char('c') => app.mode = Mode::Config,
                KeyCode::Up => {
                    if app.selected > 0 {
                        app.selected -= 1;
                    }
                }
                KeyCode::Down => {
                    if app.selected < FIELDS.len() - 1 {
                        app.selected += 1;
                    }
                }
                KeyCode::Left => app.adjust(-1.0),
                KeyCode::Right => app.adjust(1.0),
                KeyCode::Char(c) if c.is_ascii_digit() => {
                    let idx = c.to_digit(10).unwrap_or(0) as usize;
                    if idx >= 1 {
                        app.load_preset_by_idx(idx - 1);
                    }
                }
                _ => {}
            },

            Mode::Presets => {
                let visible = 20usize;
                match key.code {
                    KeyCode::Esc | KeyCode::Char('p') => app.mode = Mode::Normal,
                    KeyCode::Char('q') => break,
                    KeyCode::Up => {
                        if app.preset_sel > 0 {
                            app.preset_sel -= 1;
                            app.scroll_presets_to_selected(visible);
                        }
                    }
                    KeyCode::Down => {
                        if app.preset_sel + 1 < app.presets.len() {
                            app.preset_sel += 1;
                            app.scroll_presets_to_selected(visible);
                        }
                    }
                    KeyCode::Enter => {
                        let idx = app.preset_sel;
                        app.load_preset_by_idx(idx);
                        app.mode = Mode::Normal;
                    }
                    KeyCode::Delete | KeyCode::Backspace => {
                        let presets = app.presets.clone();
                        if let Some(name) = presets.get(app.preset_sel) {
                            let n = name.clone();
                            app.delete_preset(&n);
                        }
                    }
                    KeyCode::Char('s') => {
                        app.save_input.clear();
                        app.mode = Mode::Save;
                    }
                    KeyCode::Char(c) if c.is_ascii_digit() => {
                        let idx = c.to_digit(10).unwrap_or(0) as usize;
                        if idx >= 1 {
                            app.load_preset_by_idx(idx - 1);
                            app.mode = Mode::Normal;
                        }
                    }
                    _ => {}
                }
            }

            Mode::Save => match key.code {
                KeyCode::Esc => app.mode = Mode::Normal,
                KeyCode::Enter => {
                    let name = app.save_input.clone();
                    app.do_save(&name);
                    app.save_input.clear();
                    app.mode = Mode::Normal;
                }
                KeyCode::Backspace => {
                    app.save_input.pop();
                }
                KeyCode::Char(c) if c.is_alphanumeric() || c == '_' || c == '-' => {
                    app.save_input.push(c);
                }
                _ => {}
            },

            Mode::Config => match key.code {
                KeyCode::Esc | KeyCode::Char('c') | KeyCode::Char('q') => app.mode = Mode::Normal,
                _ => {}
            },

            Mode::Help => match key.code {
                KeyCode::Esc | KeyCode::Char('h') | KeyCode::Char('q') => {
                    app.show_help = false;
                    app.mode = Mode::Normal;
                }
                _ => {}
            },
        }
    }

    disable_raw_mode().ok();
    execute!(io::stdout(), LeaveAlternateScreen).ok();
}
