use crate::params::Params;
use std::io::{BufRead, BufReader, Write};
use std::os::unix::net::UnixStream;

pub const SOCKET_PATH: &str = "/tmp/controller.sucker";

pub enum Cmd {
    Get,
    Set { field: String, value: f64 },
    Reset,
    Load(String),
    ListPresets,
    Save(String),
}

pub fn parse_cmd(line: &str) -> Option<Cmd> {
    let mut parts = line.trim().splitn(3, ' ');
    match parts.next()? {
        "GET" => Some(Cmd::Get),
        "RESET" => Some(Cmd::Reset),
        "SET" => {
            let field = parts.next()?.to_string();
            let value: f64 = parts.next()?.parse().ok()?;
            Some(Cmd::Set { field, value })
        }
        "LOAD" => Some(Cmd::Load(parts.next()?.to_string())),
        "SAVE" => Some(Cmd::Save(parts.next()?.to_string())),
        "PRESETS" => Some(Cmd::ListPresets),
        _ => None,
    }
}

pub fn params_to_json(p: &Params) -> String {
    format!(
        r#"{{"red":{:.1},"green":{:.1},"blue":{:.1},"contrast":{:.1},"gamma":{:.1}}}"#,
        p.red, p.green, p.blue, p.contrast, p.gamma
    )
}

pub fn send_and_recv(cmd: &str) -> std::io::Result<String> {
    let mut stream = UnixStream::connect(SOCKET_PATH)?;
    writeln!(stream, "{}", cmd)?;
    let mut reader = BufReader::new(stream);
    let mut resp = String::new();
    reader.read_line(&mut resp)?;
    Ok(resp.trim().to_string())
}
