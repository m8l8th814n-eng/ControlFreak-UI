mod config;
mod daemon;
mod gamma;
mod ipc;
mod params;
mod preset;
mod sway;
mod tui;

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.iter().any(|a| a == "--daemon") {
        daemon::run();
    } else {
        tui::run();
    }
}
