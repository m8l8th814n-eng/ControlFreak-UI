use crate::params::Params;
use std::os::fd::{AsFd, FromRawFd, OwnedFd};
use std::ffi::CString;
use wayland_client::{
    protocol::{wl_output, wl_registry},
    Connection, Dispatch, EventQueue, QueueHandle,
};
use wayland_protocols_wlr::gamma_control::v1::client::{
    zwlr_gamma_control_manager_v1::ZwlrGammaControlManagerV1,
    zwlr_gamma_control_v1::{self, ZwlrGammaControlV1},
};

struct GammaControl {
    ctrl: ZwlrGammaControlV1,
    size: u32,
    failed: bool,
}

pub struct GammaState {
    manager: Option<ZwlrGammaControlManagerV1>,
    outputs: Vec<wl_output::WlOutput>,
    controls: Vec<GammaControl>,
    pending_size: Option<u32>,
    pending_failed: bool,
}

impl GammaState {
    fn new() -> Self {
        Self {
            manager: None,
            outputs: Vec::new(),
            controls: Vec::new(),
            pending_size: None,
            pending_failed: false,
        }
    }
}

impl Dispatch<wl_registry::WlRegistry, ()> for GammaState {
    fn event(
        state: &mut Self,
        registry: &wl_registry::WlRegistry,
        event: wl_registry::Event,
        _: &(),
        _conn: &Connection,
        qh: &QueueHandle<Self>,
    ) {
        if let wl_registry::Event::Global { name, interface, version } = event {
            if interface == "wl_output" {
                let out = registry.bind::<wl_output::WlOutput, _, _>(name, version.min(4), qh, ());
                state.outputs.push(out);
            } else if interface == "zwlr_gamma_control_manager_v1" {
                let mgr = registry.bind::<ZwlrGammaControlManagerV1, _, _>(name, 1, qh, ());
                state.manager = Some(mgr);
            }
        }
    }
}

impl Dispatch<wl_output::WlOutput, ()> for GammaState {
    fn event(_: &mut Self, _: &wl_output::WlOutput, _: wl_output::Event, _: &(), _: &Connection, _: &QueueHandle<Self>) {}
}

impl Dispatch<ZwlrGammaControlManagerV1, ()> for GammaState {
    fn event(
        _: &mut Self,
        _: &ZwlrGammaControlManagerV1,
        _: wayland_protocols_wlr::gamma_control::v1::client::zwlr_gamma_control_manager_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<ZwlrGammaControlV1, ()> for GammaState {
    fn event(
        state: &mut Self,
        _proxy: &ZwlrGammaControlV1,
        event: zwlr_gamma_control_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            zwlr_gamma_control_v1::Event::GammaSize { size } => {
                state.pending_size = Some(size);
            }
            zwlr_gamma_control_v1::Event::Failed => {
                state.pending_failed = true;
            }
            _ => {}
        }
    }
}

pub struct GammaClient {
    conn: Connection,
    queue: EventQueue<GammaState>,
    state: GammaState,
}

impl GammaClient {
    pub fn connect() -> Option<Self> {
        let conn = Connection::connect_to_env().ok()?;
        let mut queue = conn.new_event_queue();
        let qh = queue.handle();
        conn.display().get_registry(&qh, ());
        let mut state = GammaState::new();
        queue.roundtrip(&mut state).ok()?;
        queue.roundtrip(&mut state).ok()?;
        Some(Self { conn, queue, state })
    }

    pub fn acquire_controls(&mut self) -> bool {
        let manager = match self.state.manager.take() {
            Some(m) => m,
            None => return false,
        };
        let qh = self.queue.handle();
        let count = self.state.outputs.len();
        for i in 0..count {
            let wl = self.state.outputs[i].clone();
            self.state.pending_size = None;
            self.state.pending_failed = false;
            let ctrl = manager.get_gamma_control(&wl, &qh, ());
            let _ = self.queue.roundtrip(&mut self.state);
            if self.state.pending_failed || self.state.pending_size.is_none() {
                ctrl.destroy();
                continue;
            }
            let size = self.state.pending_size.unwrap();
            self.state.controls.push(GammaControl { ctrl, size, failed: false });
        }
        self.state.manager = Some(manager);
        !self.state.controls.is_empty()
    }

    pub fn apply(&mut self, params: &Params) {
        for ctrl in &mut self.state.controls {
            if ctrl.failed {
                continue;
            }
            if let Some(fd) = build_ramp(ctrl.size, params) {
                ctrl.ctrl.set_gamma(fd.as_fd());
            }
        }
        let _ = self.queue.roundtrip(&mut self.state);
        for ctrl in &mut self.state.controls {
            if self.state.pending_failed {
                ctrl.failed = true;
            }
        }
    }

    pub fn dispatch(&mut self) {
        let _ = self.queue.dispatch_pending(&mut self.state);
        let _ = self.conn.flush();
    }
}

fn build_ramp(size: u32, params: &Params) -> Option<OwnedFd> {
    let n = size as usize;
    let table_len = n * 3 * std::mem::size_of::<u16>();
    let template = CString::new("/tmp/controlorfreak-XXXXXX").ok()?;
    let buf: Vec<u8> = template.into_bytes_with_nul();
    let mut buf = buf;
    let fd = unsafe { mkstemp(buf.as_mut_ptr() as *mut i8) };
    if fd < 0 {
        return None;
    }
    unsafe { unlink(buf.as_ptr() as *const i8) };
    if unsafe { ftruncate(fd, table_len as i64) } < 0 {
        unsafe { close(fd) };
        return None;
    }
    let ptr = unsafe {
        mmap(std::ptr::null_mut(), table_len, 0x1 | 0x2, 0x01, fd, 0)
    };
    if ptr as isize == -1 {
        unsafe { close(fd) };
        return None;
    }
    let ramps = unsafe { std::slice::from_raw_parts_mut(ptr as *mut u16, n * 3) };
    fill_ramp(ramps, n, params);
    unsafe { msync(ptr, table_len, 4) };
    unsafe { munmap(ptr, table_len) };
    Some(unsafe { OwnedFd::from_raw_fd(fd) })
}

fn fill_ramp(ramps: &mut [u16], n: usize, params: &Params) {
    let gain = [params.raw_red(), params.raw_green(), params.raw_blue()];
    let contrast = params.raw_contrast();
    let gamma = params.raw_gamma().max(0.01);
    for i in 0..n {
        let x = if n == 1 { 1.0 } else { i as f64 / (n - 1) as f64 };
        for (ch, &g) in gain.iter().enumerate() {
            let mut y = x;
            y = (y - 0.5) * contrast + 0.5;
            y = y.clamp(0.0, 1.0);
            y = y.powf(1.0 / gamma);
            y *= g;
            ramps[ch * n + i] = (y.clamp(0.0, 1.0) * 65535.0).round() as u16;
        }
    }
}

extern "C" {
    fn mkstemp(template: *mut i8) -> i32;
    fn unlink(path: *const i8) -> i32;
    fn ftruncate(fd: i32, length: i64) -> i32;
    fn mmap(addr: *mut std::ffi::c_void, len: usize, prot: i32, flags: i32, fd: i32, offset: i64) -> *mut std::ffi::c_void;
    fn munmap(addr: *mut std::ffi::c_void, len: usize) -> i32;
    fn msync(addr: *mut std::ffi::c_void, len: usize, flags: i32) -> i32;
    fn close(fd: i32) -> i32;
}
